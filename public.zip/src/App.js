import React from 'react'
import Header from './Components/Header'
import Hero from './Components/Hero'
import Equipment from './Components/Equipment'
import Merchandise from './Components/Merchandise'
import Footer from './Components/Footer'
import Onmatch from './Components/Onmatch'
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from './Components/Home'

import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import Tshirt from './Components/Tshirt'

function App() {
  return (
    <>
{/*   
    <Header/>
    <Hero/>
    <Equipment/>
    <Onmatch/>
    <Footer/> */}



<BrowserRouter>
      <Header/>
        <Routes>
            <Route path="/" element={<Home />}/>
            <Route path="/merchandise" element={<Merchandise/>}/>
            <Route path="/merchandise/tshirt" element={<Tshirt/>}/>
        </Routes>
      <Footer/>
    </BrowserRouter>
    
    </>
  )
}

export default App
