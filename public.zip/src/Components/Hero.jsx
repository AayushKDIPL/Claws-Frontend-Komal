import React from 'react'
import "../style/Hero.css";


function Hero() {
  return (
    <div className='hero_image'>
   
   {/* <div data-aos="zoom-in-up"> */}
  <div className='heading_div container'>
 
  <div data-aos="fade-down">

  <h3 className='text-white heading1'>CONNECT WITH THE INDIA COMMUNITY OF ARM WRESTLERS</h3>
      <h2 className='text-white heading2' >30,000 MEMBERS AND COUNTING</h2>
      <div className='container btn_div'>
        <button type="button" class="btn2  ">VIEW EQUIPMENT</button>
        <button type="button" class="btn2 ">MERCHANDISE</button>
      </div>
  </div>
  </div>
  {/* </div> */}

  
    </div>
  )
}

export default Hero
