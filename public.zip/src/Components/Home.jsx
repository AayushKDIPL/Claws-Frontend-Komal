import Equipment from "./Equipment"
import Hero from "./Hero"
import Onmatch from "./Onmatch" 
const Home=()=>{
    return(
        <>
           
            <Hero/>
            
            <Equipment/>
            <Onmatch/>
            
        </>
    )
}
export default Home