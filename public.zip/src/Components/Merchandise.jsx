import React from 'react'

function Merchandise() {
  return (
    <div> 
      <h1>merchandise</h1>
      <h1>merchandise</h1>
      <h1>merchandise</h1>
    
    </div>
  )
}

export default Merchandise