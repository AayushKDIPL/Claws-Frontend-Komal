import React from 'react';
import tshirt from '../img/tshirt.JPG';
import FAT_GRIP from '../img/FAT_GRIP.JPG';
import table from '../img/table.jpg';
import cable from '../img/cable.jpg';
import '../style/Onmatch.css';

function Onmatch() {
  return (
    <div className="on-mat">
      <div className="box3">
        <div className="container main_div">
          <div className="card">
            <img className="card_img" src={tshirt} alt="Tshirt" />
            <h1 className="card_title">TSHIRT</h1>
          </div>
          <div className="card">
            <img className="card_img" src={FAT_GRIP} alt="Fat Grip" />
            <h1 className="card_title">FAT GRIP</h1>
          </div>
          <div className="card">
            <img className="card_img" src={table} alt="Table" />
            <h1 className="card_title">TABLE</h1>
          </div>
          <div className="card">
            <img className="card_img" src={cable} alt="Cable" />
            <h1 className="card_title">CABLE</h1>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Onmatch;
