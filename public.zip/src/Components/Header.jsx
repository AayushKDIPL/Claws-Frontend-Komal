import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import logo1 from "../img/logo1.png";
import "../style/Header.css";
import "../style/Search.css";
// Import Bootstrap source files  

function Header() {
  const [searchOpen, setSearchOpen] = useState(false);
  const [offcanvasOpen, setOffcanvasOpen] = useState(false);

  const handleSearchClick = () => {
    setSearchOpen(!searchOpen);
  };

  const handleOffcanvasClick = () => {
    setOffcanvasOpen(!offcanvasOpen);
  };
 
  

  return (
    <>
      <nav className="navbar navbar-expand-lg fixed-top bg">
        <div className="container-fluid">
          <img className='logo' src={logo1} alt="logo" />
          <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarNavDropdown">
            <ul className="navbar-nav me-auto mb-2 mb-lg-0">
              <li className="nav-item">
                <Link to="/" className="nav-link text-clr" aria-current="page">HOME</Link>
              </li>


              
              <li className="nav-item dropdown">
                <Link to="#" className="nav-link dropdown-toggle text-clr" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                  MERCHANDISE
                </Link>
                <ul className="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                  <li><Link to="/merchandise/tshirt" className="dropdown-item">T-Shirt</Link></li>
                  
                </ul>
              </li>

              <li className="nav-item dropdown">
                <Link to="#" className="nav-link dropdown-toggle text-clr" id="navbarDropdownMenuLink2" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                  EQUIPMENT
                </Link>
                <ul className="dropdown-menu" aria-labelledby="navbarDropdownMenuLink2">
                  <li   className="dropdown-item">ARM WRESTLING TABLE </li>
                  <li  className="dropdown-item">FIXED PULLEY SYSTEM</li>
                  <li  className="dropdown-item">MULTISPINNER </li>
                  <li className="dropdown-item">CUP POWER HANDLE</li>
                  <li  className="dropdown-item">EXPLODING HAND TRAINING SYSTEM</li>
                  <li  className="dropdown-item">L-TOOL</li>
                  <li  className="dropdown-item">EXERCISE RESISTANCE BANDS</li>
                </ul>
              </li>
            </ul>
            <div className='nav-icon d-flex'>
              <i className="fas fa-search me-3" onClick={handleSearchClick}></i>
              <button className="btn " type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasRight" aria-controls="offcanvasRight">
                <i className="fa-solid fa-store text-light"></i>
              </button>
            </div>
          </div>
        </div>
      </nav>

      {searchOpen && (
        <div className="search-bar">
          <input type="text" placeholder="Search..." />
        </div>
      )}

      <div className="offcanvas offcanvas-end" tabIndex="-1" id="offcanvasRight" aria-labelledby="offcanvasRightLabel">
        <div className="offcanvas-header">
          <h5 id="offcanvasRightLabel">CART</h5>
          <button type="button" className="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <div className="offcanvas-body">
          YOUR CART IS EMPTY
        </div>
      </div>
    </>
  );
}

export default Header;
